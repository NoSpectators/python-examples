def nameAge():
	name = raw_input("What is your name? ")
	age = int(raw_input("What is your age? "))
	print 'your name is',name 
	print 'your age is',age 
	year = 2015-age + 100
	print 'you will turn 100 in the year',year 
	
nameAge()