def mystery3(x, y):
	for i in range(1, x):
		for j in range(1, y):
			print i*j, " ", 
       		print ""
def main():
        mystery3(6, 11)
main()
