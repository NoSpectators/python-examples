def main():
    writeStars(1);
    writeStars(2);
    writeStars(3);
    writeStars(4);
    writeStars(5);

def writeStars(n):
    for i in range(n):
	print "*",
    print "\n"

main()
